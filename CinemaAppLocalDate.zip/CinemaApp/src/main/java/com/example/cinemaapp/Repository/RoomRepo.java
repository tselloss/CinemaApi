package com.example.cinemaapp.Repository;

import com.example.cinemaapp.Model.Room;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoomRepo extends JpaRepository<Room, Integer> {

}

package com.example.cinemaapp.Exceptions;

public class CustomerException extends Exception{

    public CustomerException() {
        // TODO Auto-generated constructor stub
    }

    public CustomerException(String message) {
        super(message);
    }
}
